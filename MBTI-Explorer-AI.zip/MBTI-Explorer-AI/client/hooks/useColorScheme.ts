export function useColorScheme() {
  return 'dark' as const;
}
